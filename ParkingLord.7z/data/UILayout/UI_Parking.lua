Actor = 
{
	name = "UI_Wheel",
	initial_position = { -0.0, 0.0},
	player_controller = "",
	bounding_box = 
	{
		center  = {20.0,10.0},
		extends = {20.0,10.0}
	},
	render_settings = 
	{
		sprite = "data\\UILayout\\parking_sign.dds"
	}
}
