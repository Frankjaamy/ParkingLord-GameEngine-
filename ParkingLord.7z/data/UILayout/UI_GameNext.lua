Actor = 
{
	name = "UI_Wheel",
	initial_position = { -0.0, 0.0},
	player_controller = "",
	bounding_box = 
	{
		center  = {0.0,0.0},
		extends = {0.0,0.0}
	},
	render_settings = 
	{
		sprite = "data\\UILayout\\good_job.dds"
	}
}
