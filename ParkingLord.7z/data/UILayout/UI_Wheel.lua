Actor = 
{
	name = "UI_Wheel",
	initial_position = { -0.0, 0.0},
	player_controller = "",
	bounding_box = 
	{
		center  = {0.0,40.0},
		extends = {40.0,40.0}
	},
	render_settings = 
	{
		sprite = "data\\UILayout\\steering_wheel.dds"
	}
}
